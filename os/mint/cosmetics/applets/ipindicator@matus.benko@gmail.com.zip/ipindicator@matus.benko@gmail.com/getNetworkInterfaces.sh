ip -br link | awk '{ print $1 }'
